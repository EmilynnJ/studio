import AdminDirectSetup from '../admin-direct-setup';

export default function AdminDirectSetupPage() {
  return <AdminDirectSetup />;
}