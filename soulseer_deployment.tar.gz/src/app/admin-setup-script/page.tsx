import AdminSetupScript from '../admin-setup-script';

export default function AdminSetupScriptPage() {
  return <AdminSetupScript />;
}