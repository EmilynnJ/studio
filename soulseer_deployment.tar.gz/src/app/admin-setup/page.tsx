import AdminSetup from '../admin-setup';

export default function AdminSetupPage() {
  return <AdminSetup />;
}