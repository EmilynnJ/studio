// This file is kept for reference but is not used in the application
// The app uses Firebase Authentication instead of NextAuth